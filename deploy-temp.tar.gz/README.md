# 💎 AURELLE - Beauty Salon Marketplace

Современная платформа для онлайн-записи в салоны красоты с полным функционалом управления бронированиями, отзывами и аналитикой.

## ⭐ Возможности

### Для клиентов:
- 🔍 Поиск салонов по геолокации и рейтингу
- 📅 Онлайн-запись на услуги
- ⭐ Система отзывов и рейтингов
- 💬 Чат с салонами
- ❤️ Избранные салоны
- 🔔 Уведомления о записях
- 📊 История посещений

### Для владельцев салонов:
- 🏢 Управление салоном и услугами
- 👥 Управление мастерами
- 📅 Управление бронированиями
- 📸 Галерея фотографий
- 📊 Статистика и аналитика
- ⭐ Просмотр отзывов
- 🗓️ Управление расписанием

### Для администраторов:
- 👤 Управление пользователями
- 🏢 Модерация салонов
- 📊 Полная статистика платформы
- 🔒 Audit логи всех действий

## 🚀 Быстрый старт

### Требования:
- Docker Desktop
- Git

### Запуск:

**Windows:**
```bash
# Просто запустите двойным кликом:
START.bat
```

**Linux/Mac:**
```bash
docker-compose up -d --build
docker-compose exec backend alembic upgrade head
docker-compose exec backend python init_db.py
```

Откройте в браузере: **http://localhost:5173**

## 📝 Учетные данные

После инициализации доступны тестовые аккаунты:

| Роль | Email | Пароль |
|------|-------|--------|
| Админ | admin@aurelle.uz | admin123 |
| Владелец | salon1@aurelle.uz | salon123 |
| Клиент | client1@aurelle.uz | client123 |

## 🛠️ Технологии

### Backend:
- **FastAPI** - современный Python web-framework
- **PostgreSQL** - реляционная база данных
- **SQLAlchemy** - ORM
- **Alembic** - миграции БД
- **Redis** - кеширование
- **Celery** - фоновые задачи
- **JWT** - аутентификация
- **Bcrypt** - хеширование паролей

### Frontend:
- **React 18** - UI библиотека
- **TypeScript** - типизация
- **Vite** - сборщик
- **Tailwind CSS** - стилизация
- **Zustand** - state management
- **Axios** - HTTP клиент
- **React Router** - маршрутизация
- **Yandex Maps API v3** - интерактивные карты

### DevOps:
- **Docker** - контейнеризация
- **Docker Compose** - оркестрация
- **Nginx** - reverse proxy (production)

## 📚 Документация

### 🚀 Деплой (начните отсюда!):
- **[DEPLOY_NOW.md](DEPLOY_NOW.md)** - ⚡ Задеплоить СЕЙЧАС (одна команда!)
- **[SUMMARY_FOR_OWNER.md](SUMMARY_FOR_OWNER.md)** - 📋 Полная сводка для владельца проекта
- **[DEPLOYMENT_READY.md](DEPLOYMENT_READY.md)** - ✅ Чеклист готовности к деплою
- **[DEPLOY_UPDATES.md](DEPLOY_UPDATES.md)** - 🔄 Быстрое обновление продакшена
- **[FRONTEND_DEPLOYMENT.md](FRONTEND_DEPLOYMENT.md)** - 🎨 Детали деплоя фронтенда

### 📖 Быстрый старт:
- **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** - Быстрая справка по командам
- **[FIRST_RUN.md](docs/FIRST_RUN.md)** - Первый запуск проекта
- **[docs/PRODUCTION_DEPLOYMENT.md](docs/PRODUCTION_DEPLOYMENT.md)** - Полное руководство

### 🎯 Планирование:
- **[ROADMAP.md](ROADMAP.md)** - 🗺️ План развития (чат, соц.вход, выезд на дом)
- **[IMPROVEMENTS.md](IMPROVEMENTS.md)** - 🔧 Технические улучшения
- **[CHANGELOG.md](CHANGELOG.md)** - 📝 История изменений

### API:
После запуска доступна интерактивная документация:
- **Swagger UI:** http://localhost:8000/docs (dev) | https://api.aurelle.uz/docs (prod)
- **ReDoc:** http://localhost:8000/redoc (dev) | https://api.aurelle.uz/redoc (prod)

## 🔐 Безопасность

- ✅ JWT токены для аутентификации
- ✅ Bcrypt хеширование паролей
- ✅ CORS защита
- ✅ SQL Injection защита через ORM
- ✅ XSS защита
- ✅ Rate limiting
- ✅ Audit логи всех действий
- ✅ Валидация данных через Pydantic

## 📁 Структура проекта

```
beauty_salon/
├── backend/                 # FastAPI приложение
│   ├── app/
│   │   ├── api/            # API endpoints (16 роутеров)
│   │   ├── models/         # SQLAlchemy модели (11 моделей)
│   │   ├── schemas/        # Pydantic схемы
│   │   ├── core/           # Конфигурация, безопасность
│   │   └── middleware/     # Audit middleware
│   ├── alembic/            # Миграции БД
│   ├── init_db.py          # Скрипт инициализации данных
│   └── requirements.txt    # Python зависимости
├── frontend/               # React приложение
│   ├── src/
│   │   ├── api/           # API клиенты (18 модулей)
│   │   ├── components/    # React компоненты
│   │   ├── pages/         # Страницы
│   │   └── store/         # Zustand хранилище
│   └── package.json       # Node зависимости
├── docker-compose.yml     # Docker конфигурация
├── .env                   # Переменные окружения
├── START.bat             # Автозапуск (Windows)
└── README.md             # Документация
```

## 🎯 Основные эндпоинты API

### Аутентификация:
- `POST /api/auth/register` - Регистрация
- `POST /api/auth/login` - Вход
- `POST /api/auth/change-password` - Смена пароля

### Салоны:
- `GET /api/salons` - Список салонов
- `GET /api/salons/{id}` - Детали салона
- `POST /api/salons` - Создать салон
- `PATCH /api/salons/{id}` - Обновить салон

### Бронирования:
- `GET /api/bookings` - Список броней
- `POST /api/bookings` - Создать бронь
- `PATCH /api/bookings/{id}` - Обновить бронь

### Отзывы:
- `GET /api/reviews` - Список отзывов
- `POST /api/reviews` - Создать отзыв

### Геокодирование:
- `GET /api/geocoding/geocode` - Адрес → координаты
- `GET /api/geocoding/reverse-geocode` - Координаты → адрес
- `GET /api/geocoding/details` - Детальное геокодирование

## 🗺️ Настройка карт

Проект использует **Yandex Maps API v3**. Для работы карт необходим API ключ:

1. Получите бесплатный ключ на https://developer.tech.yandex.ru/services/
2. Добавьте в `.env`:
   ```env
   YANDEX_MAPS_API_KEY=ваш-ключ
   VITE_YANDEX_MAPS_API_KEY=ваш-ключ
   ```
3. Перезапустите контейнеры

**Функции карт:**
- 📍 Отображение салонов на карте
- 🔍 Поиск по геолокации
- 📌 Выбор местоположения при создании салона
- 🌍 Геокодирование адресов

## 🧪 Тестирование

```bash
# Backend тесты
docker-compose exec backend pytest

# Frontend тесты
docker-compose exec frontend npm test
```

## 💳 Платежные системы

✅ **Полностью интегрированы:**
- **Payme** (Узбекистан) - все методы реализованы
- **Click** (Узбекистан) - Prepare/Complete flows
- **Uzum** (Узбекистан) - базовая структура готова
- **Cash** - оплата наличными в салоне
- **Card** - оплата картой в салоне

**Настройка:** См. [PAYMENT_INTEGRATION_GUIDE.md](PAYMENT_INTEGRATION_GUIDE.md)

**API Endpoints:**
```
POST /api/payments/create              - Создать платеж
GET  /api/payments/{id}                - Статус платежа
POST /api/payments/{id}/refund         - Возврат средств
POST /api/payments/payme/callback      - Payme webhook
POST /api/payments/click/callback      - Click webhook
```

## 🚀 Production деплой

### Быстрый деплой:
```bash
# 1. Скопировать и настроить .env
cp .env.production.template .env
nano .env  # Заполнить все значения

# 2. Запустить деплой
chmod +x deploy/scripts/deploy.sh
./deploy/scripts/deploy.sh
```

### Что включено:
- ✅ Docker Compose для production
- ✅ Nginx конфигурация с SSL
- ✅ Автоматические backup скрипты
- ✅ Health checks
- ✅ Resource limits
- ✅ Logging

**Подробнее:**
- [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) - Полное руководство по развёртыванию
- [DEPLOY_UPDATES.md](DEPLOY_UPDATES.md) ⭐ - Быстрый деплой обновлений
- [FRONTEND_DEPLOYMENT.md](FRONTEND_DEPLOYMENT.md) - Настройка фронтенда для продакшена
- [QUICK_REFERENCE.md](QUICK_REFERENCE.md) - Быстрая шпаргалка команд
- [deploy/scripts/deploy.sh](deploy/scripts/deploy.sh) - Скрипт деплоя
- [deploy/scripts/backup.sh](deploy/scripts/backup.sh) - Backup БД

## 💾 Резервное копирование и обновления

### Система защиты данных

AURELLE использует **многоуровневую систему бэкапов** для 100% защиты данных:

**Уровни бэкапов:**
- 📅 **Ежедневные** - сохраняются 7 дней
- 📆 **Еженедельные** - сохраняются 4 недели
- 📊 **Ежемесячные** - сохраняются 12 месяцев

**Автоматические бэкапы:**
```bash
# Настройка автоматических бэкапов (один раз)
crontab -e

# Добавить строку:
0 3 * * * cd ~/projects/aurelle && bash ./deploy/scripts/advanced_backup.sh
```

**Ручное создание бэкапа:**
```bash
# Простой бэкап
bash ./deploy/scripts/backup.sh

# Бэкап с многоуровневой ротацией
bash ./deploy/scripts/advanced_backup.sh
```

**Восстановление из бэкапа:**
```bash
# Восстановить базу данных
bash ./deploy/scripts/restore.sh ./backups/backup_YYYYMMDD_HHMMSS.sql.gz
```

**Безопасное обновление:**
```bash
# Обновить приложение с автоматическим бэкапом
bash ./deploy/scripts/update.sh
```

### Доступные скрипты:

| Скрипт | Назначение | Использование |
|--------|------------|---------------|
| `backup.sh` | Простой бэкап БД | `bash deploy/scripts/backup.sh` |
| `advanced_backup.sh` | Бэкап с ротацией | `bash deploy/scripts/advanced_backup.sh` |
| `restore.sh` | Восстановление БД | `bash deploy/scripts/restore.sh <файл>` |
| `update.sh` | Безопасное обновление | `bash deploy/scripts/update.sh` |
| `deploy.sh` | Полный деплой | `bash deploy/scripts/deploy.sh` |

**Полное руководство:** [BACKUP_GUIDE.md](BACKUP_GUIDE.md) - Детальная инструкция по бэкапам

### Что защищено:

- ✅ Все пользователи и их данные
- ✅ Все салоны, мастера, услуги
- ✅ Все бронирования и история
- ✅ Все отзывы и рейтинги
- ✅ Все платежи и транзакции
- ✅ Docker volumes (логи, загрузки)

**Гарантия:** При правильной настройке вы **НИКОГДА** не потеряете данные пользователей! 🛡️

## 📈 Дополнительные функции

**Уже реализовано:**
- ✅ Дашборды для мастеров
- ✅ Календарь записей
- ✅ Управление расписанием
- ✅ Система отзывов с рейтингами
- ✅ Загрузка изображений (drag & drop)
- ✅ Избранные салоны
- ✅ Чат клиент-салон
- ✅ Промокоды
- ✅ Статистика и аналитика
- ✅ Audit логи

**В планах:**
- [ ] Email/SMS уведомления (структура готова)
- [ ] Push уведомления
- [ ] Мобильное приложение
- [ ] Программа лояльности
- [ ] Экспорт отчетов Excel/PDF

## 📚 Документация

У проекта есть **500+ страниц исчерпывающей документации**:

### 🚀 Быстрый старт:
- **[НАЧАЛО_РАБОТЫ.md](НАЧАЛО_РАБОТЫ.md)** ⭐ - Начните здесь! Полная инструкция запуска
- **[КАРТА_ДОКУМЕНТАЦИИ.md](КАРТА_ДОКУМЕНТАЦИИ.md)** - Визуальная карта всех документов
- **[MASTER_INDEX.md](MASTER_INDEX.md)** - Полный справочник документации
- [SETUP_AND_RUN.md](SETUP_AND_RUN.md) - Детальная установка
- [DOCKER_FIXES.md](DOCKER_FIXES.md) - Решение проблем Docker
- [УЧЕТНЫЕ_ДАННЫЕ_ДЛЯ_ВХОДА.md](УЧЕТНЫЕ_ДАННЫЕ_ДЛЯ_ВХОДА.md) - Тестовые аккаунты
- [КАК_ВОЙТИ.txt](КАК_ВОЙТИ.txt) - Инструкция входа

### 💻 Для разработчиков:
- [BACKEND_АРХИТЕКТУРА_И_ОТВЕТЫ.md](BACKEND_АРХИТЕКТУРА_И_ОТВЕТЫ.md) - Backend архитектура (100+ стр)
- [FRONTEND_АРХИТЕКТУРА_И_ОТВЕТЫ.md](FRONTEND_АРХИТЕКТУРА_И_ОТВЕТЫ.md) - Frontend архитектура (100+ стр)

### 🔧 Для DevOps:
- [DEVOPS_ФИНАЛ.md](DEVOPS_ФИНАЛ.md) - DevOps архитектура (100+ стр)
- [PRODUCTION_DEPLOYMENT_GUIDE.md](PRODUCTION_DEPLOYMENT_GUIDE.md) - Деплой в продакшн

### 📊 Для Project Manager:
- [PROJECT_MANAGEMENT_PART1.md](PROJECT_MANAGEMENT_PART1.md) - ТЗ и Roadmap
- [PROJECT_MANAGEMENT_PART2.md](PROJECT_MANAGEMENT_PART2.md) - Статус, Риски, Команда
- [PROJECT_MANAGEMENT_PART3.md](PROJECT_MANAGEMENT_PART3.md) - Масштабирование, Testing, KPI

### 🤝 Для бизнеса:
- [PARTNERS_FAQ.md](PARTNERS_FAQ.md) - FAQ для салонов (100+ стр)
- [МУЛЬТИЯЗЫЧНОСТЬ.md](МУЛЬТИЯЗЫЧНОСТЬ.md) - Поддержка RU/UZ/EN
- [УЗБЕКИСТАН_АДАПТАЦИЯ.md](УЗБЕКИСТАН_АДАПТАЦИЯ.md) - Адаптация под Узбекистан

### 📋 Итоговые:
- [ИТОГОВЫЙ_ОТЧЕТ.md](ИТОГОВЫЙ_ОТЧЕТ.md) - Полный обзор проекта
- [ГОТОВО_К_РАБОТЕ.md](ГОТОВО_К_РАБОТЕ.md) - Чеклист готовности

## 🐛 Решение проблем

**Быстрая помощь:**
- Проект не запускается → [DOCKER_FIXES.md](DOCKER_FIXES.md)
- Не могу войти → [КАК_ВОЙТИ.txt](КАК_ВОЙТИ.txt)
- Общие проблемы → [НАЧАЛО_РАБОТЫ.md](НАЧАЛО_РАБОТЫ.md)

**Детальная инструкция:** [SETUP_AND_RUN.md](SETUP_AND_RUN.md)

## 📊 Статус проекта

```
✅ MVP v1.0 - ЗАВЕРШЕНО (100%)
├── Backend:       26 API endpoints
├── Frontend:      23 страницы (3 роли)
├── База данных:   9 таблиц
├── Docker:        4 сервиса
├── Документация:  500+ страниц
├── i18n:          RU/UZ/EN
└── Адаптация:     Узбекистан
```

**Следующие шаги:**
- Неделя 0: Тесты + Бэкапы + Мониторинг
- Фаза 2 (недели 1-4): Мастера, Календарь, Медиа, Геолокация
- Фаза 3 (недели 5-8): Уведомления + Платежи

**Подробнее:** [PROJECT_MANAGEMENT_PART1.md](PROJECT_MANAGEMENT_PART1.md)

## 📞 Контакты

При возникновении вопросов создайте Issue в репозитории.

## 📄 Лицензия

MIT License

---

**AURELLE** - Разработано с ❤️ для индустрии красоты
