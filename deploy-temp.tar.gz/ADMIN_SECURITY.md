# 🔐 Безопасность админ-панели AURELLE

## ⚠️ КРИТИЧЕСКИ ВАЖНО - ПРОЧИТАТЬ ПЕРВЫМ!

### Текущие данные админа (ВРЕМЕННЫЕ - СМЕНИТЬ СРОЧНО!)

- **Email**: `admin@aurelle.uz`
- **Пароль**: `admin2025` ⚠️ **СЛАБЫЙ ПАРОЛЬ! СМЕНИТЬ НЕМЕДЛЕННО!**
- **URL админ-панели**: `https://aurelle.uz/admin/dashboard`

---

## 🚨 Первоочередные действия после деплоя

### 1. Смена пароля админа (ОБЯЗАТЕЛЬНО!)

**Вариант A: Через веб-интерфейс (после входа)**

1. Зайти в админку: `https://aurelle.uz/login`
2. Логин: `admin@aurelle.uz` / Пароль: `admin2025`
3. Перейти в Настройки → Сменить пароль
4. Ввести текущий пароль и новый (минимум 8 символов)

**Вариант B: Через командную строку сервера (рекомендуется)**

```bash
# SSH на сервер
ssh root@89.39.94.194

# Сменить пароль админа
docker exec -it beauty_backend_prod python scripts/change_admin_password.py "ВашНовыйСуперСложныйПароль2025!"

# Проверка
docker exec beauty_db_prod psql -U beauty_user -d beauty_salon_db -c \
  "SELECT email, role, is_active FROM users WHERE role = 'admin';"
```

**Требования к паролю:**
- Минимум 8 символов (рекомендуется 16+)
- Буквы верхнего и нижнего регистра
- Цифры
- Специальные символы (!@#$%^&*)
- НЕ использовать словарные слова
- НЕ использовать "admin", "password", "2025" и т.п.

---

## 🛡️ Дополнительные меры безопасности

### 2. Ограничение создания новых админов

❌ **НЕТ доступа через API** - создание админов только через прямой доступ к БД!

Чтобы создать нового админа:

```bash
# Генерация хэша пароля
docker exec beauty_backend_prod python -c "
from app.core.security import get_password_hash
print(get_password_hash('НовыйПароль123!'))
"

# Создание админа в БД
docker exec beauty_db_prod psql -U beauty_user -d beauty_salon_db -c "
INSERT INTO users (name, phone, email, hashed_password, role, is_active)
VALUES (
  'Имя Админа',
  '+998901234567',
  'admin2@aurelle.uz',
  '<хэш_пароля_из_предыдущей_команды>',
  'admin',
  true
);"
```

### 3. Мониторинг доступа админов

```bash
# Проверить список всех админов
docker exec beauty_db_prod psql -U beauty_user -d beauty_salon_db -c \
  "SELECT id, email, name, phone, is_active, created_at FROM users WHERE role = 'admin';"

# Деактивировать админа (вместо удаления)
docker exec beauty_db_prod psql -U beauty_user -d beauty_salon_db -c \
  "UPDATE users SET is_active = false WHERE email = 'старый_админ@aurelle.uz';"
```

### 4. Backup паролей

📝 **Сохранить пароль в безопасном месте:**
- Менеджер паролей (1Password, Bitwarden, LastPass)
- Зашифрованный файл на личном устройстве
- Физический сейф с бумажной копией

❌ **НЕ ХРАНИТЬ:**
- В Telegram/WhatsApp чатах
- В email
- В незашифрованных текстовых файлах
- В скриншотах в облаке

---

## 🔒 Текущие ограничения доступа

### Роли и доступ:

1. **admin** (Платформенный админ) - ПОЛНЫЙ доступ:
   - Управление всеми пользователями
   - Управление всеми салонами
   - Управление всеми бронированиями
   - Финансовая статистика
   - Настройки платформы

2. **salon_owner** - доступ к своим салонам (ОТКЛЮЧЕНО ДО 22.12.2025)
3. **master** - доступ к своему расписанию (ОТКЛЮЧЕНО ДО 22.12.2025)
4. **client** - только просмотр и бронирование (АКТИВНО)

### Защита роутов:

Все админ-роуты защищены проверкой роли на уровне фронтенда И бэкенда:

```tsx
// Frontend: App.tsx
user?.role === 'admin' ? <AdminLayout /> : <Navigate to="/login" />

// Backend: auth.py
current_user: User = Depends(get_current_user)
if current_user.role != "admin":
    raise HTTPException(status_code=403)
```

---

## 📊 Полная очистка тестовых данных

Если нужно вернуться к чистой БД:

```bash
# ВНИМАНИЕ: Удалит ВСЕ данные (включая админа!)
docker exec beauty_db_prod psql -U beauty_user -d beauty_salon_db -c "
DELETE FROM service_masters;
DELETE FROM services;
DELETE FROM masters;
DELETE FROM salons;
DELETE FROM users;
"

# Потом пересоздать админа заново
docker exec beauty_backend_prod python -c "
from app.core.security import get_password_hash
print(get_password_hash('НовыйБезопасныйПароль2025!'))
"

docker exec beauty_db_prod psql -U beauty_user -d beauty_salon_db -c "
INSERT INTO users (name, phone, email, hashed_password, role, is_active)
VALUES ('Platform Admin', '+998900000000', 'admin@aurelle.uz',
        '<хэш>', 'admin', true);
"
```

---

## 🎯 Чеклист после деплоя

- [ ] Сменил пароль админа на сильный (16+ символов)
- [ ] Сохранил пароль в менеджере паролей
- [ ] Проверил вход в админку с новым паролем
- [ ] Проверил, что обычные пользователи НЕ могут зайти в `/admin/*`
- [ ] Удалил тестовых пользователей из БД
- [ ] Настроил регулярный мониторинг админских аккаунтов

---

## 📞 Поддержка

Если забыли пароль админа - используйте скрипт `change_admin_password.py` через SSH доступ к серверу.

**ВАЖНО**: Доступ к серверу (SSH) = полный контроль над платформой. Защитите SSH ключи!

---

Дата создания: 22.12.2025
Дата последнего обновления: 22.12.2025
