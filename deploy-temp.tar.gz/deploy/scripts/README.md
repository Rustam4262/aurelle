# 🛠️ Deploy Scripts - Скрипты деплоя

Автоматизированные скрипты для управления продакшн окружением AURELLE.

---

## 📋 Список скриптов

### 🚀 Основные скрипты деплоя

#### 1. `update.sh` - Главный скрипт обновления
**Использование:**
```bash
bash ./deploy/scripts/update.sh
```

**Что делает:** Полное обновление продакшн окружения (8 шагов):
1. ✅ Валидация переменных окружения
2. ✅ Бэкап базы данных
3. ✅ Git pull (получение обновлений)
4. ✅ Пересборка Docker образов
5. ✅ Перезапуск контейнеров
6. ✅ Применение миграций БД
7. ✅ Очистка Docker мусора
8. ✅ Проверка здоровья системы
9. ✅ Отправка уведомления в Telegram

**Когда использовать:** При каждом обновлении продакшена

**Время выполнения:** ~2-3 минуты

---

#### 2. `deploy.sh` - Первичный деплой
**Использование:**
```bash
bash ./deploy/scripts/deploy.sh
```

**Что делает:** Первоначальная настройка продакшн окружения:
- Проверка требований (Docker, docker-compose, git)
- Создание необходимых директорий
- Настройка переменных окружения
- Первый запуск всех сервисов

**Когда использовать:** При первом деплое на новый сервер

**Время выполнения:** ~5-10 минут

---

### 🔒 Скрипты работы с данными

#### 3. `backup.sh` - Простой бэкап
**Использование:**
```bash
bash ./deploy/scripts/backup.sh
```

**Что делает:**
- Создаёт дамп PostgreSQL базы данных
- Сжимает через gzip
- Сохраняет в `backups/aurelle_YYYYMMDD_HHMMSS.sql.gz`

**Когда использовать:**
- Автоматически вызывается в `update.sh`
- Вручную перед важными изменениями

**Время выполнения:** ~10-30 секунд (зависит от размера БД)

**Пример:**
```bash
# Перед важным изменением
bash ./deploy/scripts/backup.sh
# Результат: backups/aurelle_20251209_173000.sql.gz
```

---

#### 4. `advanced_backup.sh` - Расширенный бэкап
**Использование:**
```bash
bash ./deploy/scripts/advanced_backup.sh
```

**Что делает:**
- Бэкап базы данных (как backup.sh)
- Бэкап uploads (загруженные файлы)
- Бэкап конфигурации (.env файлы)
- Автоматическая ротация (удаление старых бэкапов >7 дней)
- Опциональная отправка на S3/облако

**Когда использовать:**
- Перед крупными изменениями
- Периодически через cron (раз в день)

**Время выполнения:** ~1-5 минут

**Настройка автоматического бэкапа:**
```bash
crontab -e

# Добавьте (каждый день в 3:00 ночи):
0 3 * * * cd ~/projects/aurelle && bash ./deploy/scripts/advanced_backup.sh
```

---

#### 5. `restore.sh` - Восстановление из бэкапа
**Использование:**
```bash
bash ./deploy/scripts/restore.sh <путь_к_бэкапу>
```

**Что делает:**
- Останавливает сервисы
- Восстанавливает базу данных из бэкапа
- Перезапускает сервисы
- Проверяет работоспособность

**⚠️ ОСТОРОЖНО:** Полностью заменяет текущую БД!

**Когда использовать:**
- После сбоя
- Откат к предыдущей версии
- Миграция данных

**Время выполнения:** ~1-2 минуты

**Примеры:**
```bash
# Восстановить последний бэкап
bash ./deploy/scripts/restore.sh backups/aurelle_20251209_173000.sql.gz

# Найти последний бэкап и восстановить
LATEST=$(ls -t backups/*.sql.gz | head -1)
bash ./deploy/scripts/restore.sh "$LATEST"
```

---

### 📊 Скрипты мониторинга

#### 6. `check_health.sh` - Проверка здоровья системы
**Использование:**
```bash
bash ./deploy/scripts/check_health.sh
```

**Что проверяет:**
- ✅ Frontend доступен (https://aurelle.uz)
- ✅ API работает (https://api.aurelle.uz/health)
- ✅ API Docs доступна
- ✅ Все Docker контейнеры запущены
- ✅ Использование диска (warning если >80%)
- ✅ Использование памяти (warning если >80%)
- ✅ Наличие свежих бэкапов (<24ч)

**Когда использовать:**
- После каждого деплоя (автоматически в update.sh)
- Периодически через cron
- При подозрении на проблемы

**Время выполнения:** ~5-10 секунд

**Настройка автоматической проверки:**
```bash
crontab -e

# Добавьте (каждые 5 минут):
*/5 * * * * cd ~/projects/aurelle && bash ./deploy/scripts/check_health.sh
```

**Выход:** Отправляет алерты в Telegram при обнаружении проблем

---

#### 7. `validate_env.sh` - Валидация переменных окружения
**Использование:**
```bash
bash ./deploy/scripts/validate_env.sh
```

**Что проверяет:**

**Критические переменные** (deployment fails if missing):
- DATABASE_URL
- SECRET_KEY (минимум 32 символа)
- POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_DB

**Важные переменные** (warnings):
- VITE_YANDEX_MAPS_API_KEY
- CORS_ORIGINS
- FRONTEND_URL
- API_URL

**Опциональные переменные** (info):
- SMTP_HOST, SMTP_USER, SMTP_PASSWORD
- SMS_API_TOKEN
- PAYME_MERCHANT_ID, CLICK_MERCHANT_ID
- TELEGRAM_BOT_TOKEN

**Дополнительные проверки:**
- Длина SECRET_KEY (рекомендуется 64+ символов)
- Формат DATABASE_URL (должен начинаться с `postgresql://`)
- Значения URL (development vs production)

**Когда использовать:**
- Автоматически перед каждым деплоем (в update.sh)
- После изменения .env файла
- При настройке нового сервера

**Время выполнения:** ~1 секунда

**Пример вывода:**
```
==========================================
  Environment Variables Validation
==========================================

Checking CRITICAL variables...
[✓] DATABASE_URL is set
[✓] SECRET_KEY is set
[✓] POSTGRES_USER is set
...

All checks completed!
```

---

#### 8. `send_telegram.sh` - Telegram уведомления
**Использование:**
```bash
bash ./deploy/scripts/send_telegram.sh "Ваше сообщение"
```

**Что делает:**
- Отправляет сообщение в Telegram бот
- Поддерживает HTML форматирование
- Graceful fallback если не настроен

**Настройка:**
1. Создайте бота через [@BotFather](https://t.me/BotFather)
2. Получите токен бота
3. Узнайте свой chat_id через [@userinfobot](https://t.me/userinfobot)
4. Добавьте в `.env`:
   ```env
   TELEGRAM_BOT_TOKEN=ваш_токен
   TELEGRAM_ADMIN_CHAT_ID=ваш_chat_id
   ```

**Когда использовать:**
- Автоматически в update.sh (успешный деплой)
- Автоматически в check_health.sh (алерты)
- Вручную для кастомных уведомлений

**Время выполнения:** ~1 секунда

**Примеры:**
```bash
# Простое сообщение
bash ./deploy/scripts/send_telegram.sh "Тест уведомления"

# HTML форматирование
bash ./deploy/scripts/send_telegram.sh "<b>Важно!</b> Система обновлена"

# С эмодзи
bash ./deploy/scripts/send_telegram.sh "✅ Деплой успешен!"

# Многострочное
bash ./deploy/scripts/send_telegram.sh "Статус системы:
✅ Frontend: OK
✅ Backend: OK
✅ Database: OK"
```

---

## 🔄 Типичные сценарии использования

### 1. Регулярное обновление продакшена

```bash
# На сервере
ssh root@89.39.94.194
cd ~/projects/aurelle

# Получить изменения
git pull

# Обновить (ВСЁ АВТОМАТИЧЕСКИ!)
bash ./deploy/scripts/update.sh
```

**Результат:**
- ✅ Новый код задеплоен
- ✅ Бэкап создан
- ✅ БД обновлена
- ✅ Всё проверено
- ✅ Уведомление отправлено

---

### 2. Проверка здоровья системы

```bash
# Проверить сейчас
bash ./deploy/scripts/check_health.sh

# Или настроить автоматическую проверку
crontab -e
# Добавить:
*/5 * * * * cd ~/projects/aurelle && bash ./deploy/scripts/check_health.sh
```

---

### 3. Бэкап перед важным изменением

```bash
# Создать бэкап
bash ./deploy/scripts/backup.sh

# Запомнить имя файла
BACKUP_FILE=$(ls -t backups/*.sql.gz | head -1)
echo "Backup: $BACKUP_FILE"

# Сделать изменение
# ...

# Если что-то пошло не так, откатиться
bash ./deploy/scripts/restore.sh "$BACKUP_FILE"
```

---

### 4. Откат к предыдущей версии

```bash
# 1. Найти предыдущий коммит
git log --oneline -5

# 2. Откатиться
git checkout <previous-commit-hash>

# 3. Обновить
bash ./deploy/scripts/update.sh

# Или можно откатить только БД
bash ./deploy/scripts/restore.sh backups/aurelle_20251209_120000.sql.gz
```

---

### 5. Настройка нового сервера

```bash
# 1. Клонировать репозиторий
git clone <repo-url>
cd aurelle

# 2. Настроить .env
cp .env.production.template .env
nano .env

# 3. Первичный деплой
bash ./deploy/scripts/deploy.sh

# 4. Настроить автоматические задачи
crontab -e
# Добавить:
0 3 * * * cd ~/projects/aurelle && bash ./deploy/scripts/advanced_backup.sh
*/5 * * * * cd ~/projects/aurelle && bash ./deploy/scripts/check_health.sh
```

---

## 🔧 Переменные окружения для скриптов

Некоторые скрипты используют переменные из `.env`:

### Для всех скриптов:
```env
DATABASE_URL=postgresql://user:pass@host:5432/db
POSTGRES_USER=aurelle
POSTGRES_PASSWORD=your_secure_password
POSTGRES_DB=aurelle
```

### Для check_health.sh и send_telegram.sh:
```env
TELEGRAM_BOT_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
TELEGRAM_ADMIN_CHAT_ID=123456789
```

### Для advanced_backup.sh (опционально):
```env
S3_BUCKET=my-backups-bucket
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
```

---

## 📊 Логи и отладка

### Включить debug режим в любом скрипте:

```bash
# Добавить в начало скрипта (после #!/bin/bash)
set -x  # Показывать каждую команду
set -e  # Остановиться при ошибке
```

### Посмотреть что делает скрипт:

```bash
# Вместо запуска скрипта, посмотрите код
cat ./deploy/scripts/update.sh

# Или с подсветкой синтаксиса
bat ./deploy/scripts/update.sh
```

### Запустить скрипт вручную (построчно):

```bash
# Скопируйте команды из скрипта и запускайте по одной
# Это поможет найти проблему
```

---

## 🆘 Troubleshooting

### Проблема: Скрипт не запускается (Permission denied)

```bash
# Сделать исполняемым
chmod +x ./deploy/scripts/*.sh

# Или запускать через bash
bash ./deploy/scripts/update.sh
```

---

### Проблема: "command not found: docker-compose"

```bash
# Проверить установку Docker Compose
docker-compose --version

# Или использовать docker compose (v2)
# Отредактируйте скрипты, замените:
docker-compose  →  docker compose
```

---

### Проблема: Telegram уведомления не работают

```bash
# 1. Проверить переменные
echo $TELEGRAM_BOT_TOKEN
echo $TELEGRAM_ADMIN_CHAT_ID

# 2. Если пусто, проверить .env
cat .env | grep TELEGRAM

# 3. Загрузить переменные
source .env

# 4. Попробовать отправить вручную
bash ./deploy/scripts/send_telegram.sh "Test"
```

---

### Проблема: check_health.sh показывает ошибки

```bash
# Посмотреть детали каждой проверки

# Frontend
curl -I https://aurelle.uz

# API
curl https://api.aurelle.uz/health

# Контейнеры
docker-compose -f docker-compose.prod.yml ps

# Диск
df -h

# Память
free -h
```

---

## 📚 Связанная документация

- **[DEPLOY_NOW.md](../../DEPLOY_NOW.md)** - Быстрый гайд по деплою
- **[DEPLOYMENT_READY.md](../../DEPLOYMENT_READY.md)** - Чеклист готовности
- **[SUMMARY_FOR_OWNER.md](../../SUMMARY_FOR_OWNER.md)** - Сводка для владельца

---

## ⚡ Быстрая справка (Cheat Sheet)

```bash
# Обновить продакшен
bash ./deploy/scripts/update.sh

# Проверить здоровье
bash ./deploy/scripts/check_health.sh

# Создать бэкап
bash ./deploy/scripts/backup.sh

# Восстановить из бэкапа
bash ./deploy/scripts/restore.sh backups/latest.sql.gz

# Проверить env переменные
bash ./deploy/scripts/validate_env.sh

# Отправить уведомление
bash ./deploy/scripts/send_telegram.sh "Message"

# Посмотреть логи
docker-compose -f docker-compose.prod.yml logs --tail=50

# Перезапустить
docker-compose -f docker-compose.prod.yml restart
```

---

**Все скрипты протестированы и готовы к использованию! 🚀**
